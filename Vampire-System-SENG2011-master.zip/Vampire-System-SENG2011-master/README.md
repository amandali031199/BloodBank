# Vampire System - SENG2011-Project

This is a database system developed for a hypothetical organization Vampire PVT. LTD. in order to manage their blood supplies. This was done as a part of the SENG2011 Group Project

## Instructions:
1. Download the Repository
2. Open the terminal and switch to the repository
3. Run the command *python3 run.py* and open the link in the browser

## Collaborators:
* **Lavanya Sood** - *Frontend Design and development, User login and registration backend implemented* 
* **Yin Huey** - *Python backend for blood database and request requirement*
* **Amanda Li** - *Backend for warning system,handling and adding tested/non-tested blood*
* **Sarah Oakman** - *Backend for searching*
* **Yiyun Yang** - *Backend for blood inventory page*
